# RBF v1.33 research archive

Read Observed Recoverable Behavioral Failures in LLM Workflows.pdf. The current manuscript supersedes historical interpretations; raw study results remain unchanged.

- Study_1: 576 frozen responses, original human audit, AI rubric review and HTML rendering checks.
- Study_1/Independent_followup: 36 scored outputs and 39 unscored packet entries; submitted labels, disagreements and author-reported rater provenance.
- Study_2: 100 scheduled slots, 110 attempts, artifacts and reconstruction boundaries.
- Historical_and_prospective: previous manuscripts, pilot records and unexecuted plans.
- source: editable manuscript blocks, builder and figure assets.

The two studies and separate audits are not pooled into a larger sample. No new model experiment was run for this revision. Historical files are preserved, including superseded wording. Current manuscript property metadata was cleared; research provenance remains in the archive. Public reviewer data are de-identified. This unmasked archive is unsuitable for blinded scoring.

Accounting scripts: Study_1/reproduce_decomposition.py; Study_1/AI_rubric_review/reproduce_review.py; Study_1/Independent_followup/reproduce_review.py; Study_2/reproduce_summary.py. These reproduce accounting, not independent semantic validation. SHA256.json records file integrity.
