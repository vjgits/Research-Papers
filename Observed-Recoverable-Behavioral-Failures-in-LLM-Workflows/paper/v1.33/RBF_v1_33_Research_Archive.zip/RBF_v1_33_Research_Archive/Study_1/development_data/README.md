# RBF v1.25 reproducibility data

This is the completed 576-response development collection, not the older Claude workbook experiment or the unrun holdout. No Gemini observations are included. Raw answers and frozen AI-assisted labels are unchanged. Human labels are de-identified and retain uncertainty; free-text notes remain private. No consensus adjudication has been invented.

## Reproduce the numbers
Run `python3 reproduce_results.py` with Python 3. It uses only the standard library, makes no model calls, checks every answer hash, and prints the manuscript counts. It also compares them with expected_results.json. No API setup or payment is needed.

Optionally run `python3 reproduce_screen.py` to repeat the original dataset-specific screening logic. Only paths and output destinations were adapted. It writes to recomputed_screen/. This does not provide an independent validation of the semantic codebook. The full raw answers, codebook, and acceptance rubric permit independent review.

## How to inspect one case
Find its label in plan.json. Open the matching file under answers/. Its task_id names the prompt under prompts/. VIS tasks also use the matching PNG under attachments/. Consult acceptance_rubric.json, then compare with the frozen score. A is initial; B is a fresh repeat; C is a neutral retry from A; E is a separate verification retry from the same A. C never feeds E. The exact two follow-up prompts appear in the manuscript. The conditions catalog also contains unexecuted alternatives; their presence is not evidence of collection.

## Provenance and limits
protocol/ preserves the collection method, prior analysis plan and audit amendment as historical documents. Statements that human scoring is pending describe their creation time; the current submitted labels are in human_marks_deidentified.json. The original frozen-input hash manifest names the original archive layout, including a preview HTML not distributed here; use checksums.json for this distribution's paths. source_integrity_check.json records the separate check against the retained full archive, which is not included because it contains operational metadata. Source submission hashes refer to private exact exports, not their de-identified derivative.

The original rater packet assignment is fully represented by the labels in human_marks_deidentified.json and audit_design.json. Primary overlap agreement excludes the known assisted shared item. There are 72 ratings, 60 distinct answers, and 11 unassisted shared pairs. The balanced sample is not a simple random prevalence sample. The data do not establish browser-level HTML validity or independent expert validation of all failures.

checksums.json verifies the distributed evidence files before optional recomputation. Changing hosted models and product instructions mean rerunning the prompts may produce different answers. No public archival DOI is claimed. The author retains the original exports and complete provider logs.
