"""Recompute the manuscript's descriptive counts. Python 3 standard library only.
No network, model calls, or changes to the frozen inputs/labels.
Run from any directory: python3 reproduce_results.py
"""
from pathlib import Path
import json, hashlib
from collections import Counter
R=Path(__file__).resolve().parent
def read(name):return json.loads((R/name).read_text())
plan=read('plan.json');score_rows=read('AI_screening_576.json');scores={x['label']:x for x in score_rows}
assert len(plan)==len(scores)==576
assert len({x['label'] for x in plan})==576
assert {x['label'] for x in plan}==set(scores)
for x in score_rows:
 assert hashlib.sha256((R/'answers'/f"{x['label']}.txt").read_bytes()).hexdigest()==x['answer_sha256']
 expected='fail' if 'fail' in [x['content'],x['format']] else 'uncertain' if 'uncertain' in [x['content'],x['format']] else 'pass'
 assert x['overall']==expected
def transition(labels,cond):
 out=Counter()
 for x in labels:
  if x['condition']!='A':continue
  a=scores[x['block']+'-A']['overall'];b=scores[x['block']+'-'+cond]['overall']
  assert 'uncertain' not in (a,b)
  out[str(int(a=='pass'))+str(int(b=='pass'))]+=1
 return {k:out[k] for k in ['00','01','10','11']}
def success(rows):return {c:sum(scores[x['label']]['overall']=='pass' for x in rows if x['condition']==c) for c in 'ABCE'}
models=sorted({x['model'] for x in plan});results={'responses':len(scores),'tasks':len({x['task_id'] for x in plan}),'configuration_successes':{},'A_E_transitions':{},'A_C_transitions':{}}
for m in models:
 rows=[x for x in plan if x['model']==m]
 results['configuration_successes'][m]=success(rows)
 results['A_E_transitions'][m]=transition(rows,'E');results['A_C_transitions'][m]=transition(rows,'C')
results['all_successes']=success(plan);results['all_A_E']=transition(plan,'E')
results['dimension_counts']={f:dict(Counter(x[f] for x in scores.values())) for f in ['content','format','target_failure','overall']}
results['family_E_format_failures']={f:sum(x['condition']=='E' and x['task_id'].split('-')[1]==f and x['format']=='fail' for x in scores.values()) for f in sorted({x['task_id'].split('-')[1] for x in plan})}
core=[x for x in plan if x['task_id'].split('-')[1] not in ['AUD','BOUND','HTML']]
results['posthoc_six_family']={'successes':success(core),'A_E':transition(core,'E'),'by_configuration':{m:success([x for x in core if x['model']==m]) for m in models}}
marks=read('human_marks_deidentified.json');human={who:{x['label']:x for x in marks if x['rater']==who} for who in ['Rater 1','Rater 2']}
shared=set(human['Rater 1'])&set(human['Rater 2']);assisted={x['label'] for x in marks if x['item_specific_assistance']};union=set().union(*(set(v) for v in human.values()))
fields=['content','format','target_failure']
def agree(a,b,labels):
 return {f:{'agree':sum(a[x][f]==b[x][f] for x in labels),'n':len(labels),'uncertain_either':sum('uncertain' in (a[x][f],b[x][f]) for x in labels),'decidable_agree':sum(a[x][f]==b[x][f] and a[x][f]!='uncertain' for x in labels),'decidable_n':sum('uncertain' not in (a[x][f],b[x][f]) for x in labels)} for f in fields}
results['human']={'ratings':len(marks),'unique_outputs':len(union),'shared':len(shared),'primary_shared':len(shared-assisted),'raw_counts':{who:{f:dict(Counter(x[f] for x in mm.values())) for f in fields} for who,mm in human.items()},'shared_primary':agree(human['Rater 1'],human['Rater 2'],shared-assisted),'shared_all':agree(human['Rater 1'],human['Rater 2'],shared),'against_screen':{who:agree(mm,scores,{x for x in mm if not mm[x]['item_specific_assistance']}) for who,mm in human.items()},'screened_audit_overall':dict(Counter(scores[x]['overall'] for x in union))}
assert results['all_successes']=={'A':142,'B':142,'C':142,'E':115}
assert results['all_A_E']=={'00':0,'01':2,'10':29,'11':113}
assert len(marks)==72 and len(union)==60 and len(shared-assisted)==11
assert results['posthoc_six_family']['A_E']=={'00':0,'01':2,'10':11,'11':83}
expected=R/'expected_results.json'
if expected.exists():assert read('expected_results.json')==results,'Counts differ from packaged expected results'
print(json.dumps(results,indent=2))
