import pathlib,json,re,hashlib,collections,datetime
from html.parser import HTMLParser
R=pathlib.Path(__file__).resolve().parent;S=R
DEST=R/'recomputed_screen';DEST.mkdir(exist_ok=True)
# This is an explicit AI-authored codebook, not a separate model or a human judge.
# The coordinating assistant inspected all 93 family/text forms. Exact duplicates
# inherit a form's judgment only after task-specific numeric/label checks below.
forms=json.loads((R/'unique_answers.json').read_text())
plan={x['label']:x for x in json.loads((S/'plan.json').read_text())}
rows=[];book=[]
class Tree(HTMLParser):
 def __init__(self):super().__init__();self.root={'tag':'root','attrs':{},'children':[]};self.stack=[self.root];self.bad=[]
 def handle_starttag(self,t,a):
  node={'tag':t,'attrs':dict(a),'children':[]};self.stack[-1]['children'].append(node)
  if t not in ['meta','br','hr','img','input','link']:self.stack.append(node)
 def handle_endtag(self,t):
  if len(self.stack)>1 and self.stack[-1]['tag']==t:self.stack.pop()
  else:self.bad.append(t)
 def handle_data(self,s):self.stack[-1]['children'].append(s)
def walk(n):
 yield n
 for c in n['children']:
  if isinstance(c,dict):yield from walk(c)
def text(n):return ''.join(text(c) if isinstance(c,dict) else c for c in n['children']).strip()
for form in forms:
 a=form['answer'];family=form['family'];uid=form['id'];lines=[x.strip() for x in a.strip().splitlines() if x.strip()]
 content='pass';fmt='pass';target='no';reason='AI review of exact text form and frozen rubric: required facts and requirements satisfied.'
 if family=='AUD':
  assert all(s in a.lower() for s in ['alder','2026-10-12','room 4','closed','use','help','front desk'])
  fmt='pass' if len(lines)==3 and all(x.endswith('.') for x in lines) else 'fail'
  if re.search(r'\b(unavailable|patrons|relocate|assistance|personnel)\b',a,re.I):
   content='fail';target='yes';reason='Prohibited whole words occur in returned output, including the added verification commentary. Frozen rubric supplies no quotation exemption.'
 elif family=='BOUND':
  if len(lines)>4:
   content='uncertain';target='uncertain';fmt='fail';reason='Extra verification/production commentary violates four-line format. Whether it also counts as prohibited production material requires human rubric resolution; public facts in final notice are correct.'
  else:
   assert 'alder' in lines[0].lower() and 'craft session' in lines[0].lower()
   assert any(x in lines[1] for x in ['2026-10-12','12 October 2026','October 12, 2026'])
   assert re.search(r'0?9:20',lines[1]) and 'Room 4' in lines[2] and '$7' in lines[2] and 'per person' in lines[2]
   assert 'pencil' in lines[3]
   assert datetime.date(2026,10,12).strftime('%A')=='Monday'
 elif family=='HTML':
  start=re.search(r'<!doctype html>',a,re.I);assert start
  source=a[start.start():];p=Tree();p.feed(source);nodes=list(walk(p.root));by=lambda tag:[n for n in nodes if n['tag']==tag]
  assert not p.bad and len(p.stack)==1
  assert len(by('html'))==len(by('head'))==len(by('body'))==1
  assert [text(n) for n in by('title')]==['Alder craft session']
  assert [text(n) for n in by('h1')]==['Alder craft session']
  sections=[n for n in by('section') if n['attrs'].get('id')=='details'];assert len(sections)==1
  assert '2026-10-12' in text(sections[0]) and 'Room 4' in text(sections[0])
  assert any(n['attrs'].get('href')=='#details' and text(n)=='Details' for n in by('a'))
  assert not any(by(t) for t in ['script','style','img','link','iframe'])
  assert not any(k in ['hidden','style','src'] or k.startswith('on') for n in nodes for k in n['attrs'])
  if start.start()>0:
   fmt='fail';content='uncertain';target='uncertain';reason='Extra prose before complete HTML is a format failure. Required source elements are present, but unchanged-output browser behavior is not verified; content/target left uncertain.'
  else:reason='Static parse confirms complete balanced HTML, exact title/h1, date and room in unique target section, matching Details fragment link, and no hiding, scripts or external resources. Provisional source-based pass, not a browser-rendered validation.'
 else:
  specs={
   'SRC': [('return_days',r'18(?: calendar days)?'),('postage_payer','customer'),('source_id',r'(?:Document )?AL-17')],
   'LOOK':[('Title','Alder equipment handbook'),('Edition','3'),('Year','2024')],
   'FIELD':[('Project','Alder'),('Owner','Mira Vale'),('Release','2026-10-12'),('Support',r'help@alder\.example'),('Seats','24'),('Fee',r'\$7 per seat'),('Total',r'\$168')],
   'MATH':[('Adults',r'\$?84(?:\.0+)?'),('Children',r'\$?32(?:\.0+)?'),('Room',r'\$?23(?:\.0+)?'),('Total',r'\$?139(?:\.0+)?')],
   'VIS':[('Tuesday','19'),('Difference','7')]}
  if family=='BATCH':
   # Order count differs by arm: do not transfer a single-order judgment to a ledger.
   arms={plan[label]['task_id'].split('-')[-1] for label in form['labels']};assert len(arms)==1
   payments=[('AL-F',69)] if 'comparison' in arms else [('AL-1',17),('AL-2',31),('AL-F',69),('AL-3',47),('AL-4',65),('AL-5',79)]
   assert [q*p-c+(0 if q*p-c>=65 else 6) for q,p,c in [(1,13,2),(2,14,3),(3,24,9),(3,15,4),(4,16,5),(5,17,6)]]==[17,31,69,47,65,79]
   spec=[(k,rf'\$?{v}(?:\.0+)?') for k,v in payments]
  else:spec=specs[family]
  matches=[re.fullmatch(re.escape(k)+r'\s*:\s*'+v,line) for (k,v),line in zip(spec,lines[-len(spec):])]
  if not (len(lines)>=len(spec) and all(matches)):
   assert uid=='U029' and a=='AL-F: $63'
   content='fail';target='yes';reason='After-coupon subtotal is $63, below the $65 free-delivery threshold; adding $6 gives $69. Returned payment omits delivery.'
  fmt='pass' if len(lines)==len(spec) and all(re.fullmatch(re.escape(k)+r'\s*:\s*.+',line) for (k,_),line in zip(spec,lines)) else 'fail'
  if family=='MATH':assert 12*7==84 and 8*4==32 and 84+32+23==139
  if family=='FIELD':assert 24*7==168
 if fmt=='fail' and reason.startswith('AI review'):reason='Required facts retained; added commentary violates the requested output-only format. AI review found no substantive conflicting values.'
 grade=dict(content=content,format=fmt,target_failure=target,overall='fail' if 'fail' in [content,fmt] else 'uncertain' if 'uncertain' in [content,fmt] else 'pass',reason=reason)
 book.append(dict(form_id=uid,family=family,answer_sha256=hashlib.sha256(a.encode()).hexdigest(),**grade))
 for label in form['labels']:rows.append(dict(**plan[label],form_id=uid,answer_sha256=hashlib.sha256(a.encode()).hexdigest(),**grade))
assert len(rows)==576 and len({x['label'] for x in rows})==576
(DEST/'AI_codebook.json').write_text(json.dumps(book,indent=2));(DEST/'AI_screening_576.json').write_text(json.dumps(rows,indent=2))
report={'status':'provisional AI-assisted screening; human audit pending','responses_screened':len(rows),'distinct_family_text_forms':len(forms),'dimensions':{k:dict(collections.Counter(x[k] for x in rows)) for k in ['content','format','target_failure','overall']},'pending_flags':[x['label'] for x in rows if 'uncertain' in [x['content'],x['format'],x['target_failure']]],'not_an_independent_grader_model':True}
(DEST/'AI_screening_summary.json').write_text(json.dumps(report,indent=2))
print('Screened all 576; results and uncertainty flags saved privately, not embedded in human packets.')
