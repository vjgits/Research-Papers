from playwright.sync_api import sync_playwright
import json, pathlib

docs = {"docA":"002/016/029/074","docB":"013","docC":"009/042","docD":"026/038"}
out={}
with sync_playwright() as p:
    b = p.chromium.launch()
    for name,ids in docs.items():
        pg = b.new_page()
        pg.goto("file://"+str(pathlib.Path(name and f"html/{name}.html").resolve()))
        r={}
        r["cases"]=ids
        r["title"]=pg.title()
        r["h1_count"]=pg.locator("h1").count()
        r["h1_text"]=pg.locator("h1").first.inner_text()
        r["anchor_text"]=pg.locator("a[href='#details']").first.inner_text()
        r["anchor_target_exists"]=pg.locator("#details").count()==1
        body=pg.locator("body").inner_text()
        r["date_visible"]="2026-10-12" in body
        r["room_visible"]="Room 4" in body
        # visibility + contrast under browser defaults
        r["details_section_visible"]=pg.locator("#details").is_visible()
        r["link_visible"]=pg.locator("a[href='#details']").first.is_visible()
        style=pg.evaluate("""() => {
            const s=getComputedStyle(document.body);
            const a=document.querySelector("a[href='#details']");
            const as=getComputedStyle(a);
            const sec=document.querySelector('#details');
            const ss=getComputedStyle(sec);
            return {bodyColor:s.color, bodyBg:s.backgroundColor, linkColor:as.color,
                    secColor:ss.color, secBg:ss.backgroundColor,
                    secRect: sec.getBoundingClientRect().height};
        }""")
        r.update(style)
        # does the in-page jump work
        pg.click("a[href='#details']")
        r["hash_after_click"]=pg.evaluate("() => location.hash")
        r["scripts"]=pg.locator("script").count()
        r["imgs"]=pg.locator("img").count()
        r["ext_links"]=pg.evaluate("""() => Array.from(document.querySelectorAll('link[href],script[src],img[src]')).length""")
        out[name]=r
        pg.close()
    b.close()
print(json.dumps(out, indent=2))
