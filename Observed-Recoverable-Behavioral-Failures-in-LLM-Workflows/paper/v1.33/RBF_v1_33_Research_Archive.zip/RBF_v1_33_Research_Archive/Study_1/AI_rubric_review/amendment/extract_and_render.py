import re, json, pathlib, hashlib
from playwright.sync_api import sync_playwright

UP = pathlib.Path("/root/.claude/uploads/3b472cfa-e380-53e4-ae21-226b42f2813d")
BATCH = ["e8e7832f-Batch_1_15_cases.md","3b48d915-Batch_2_15_cases.md","a2ecf094-Batch_3_15_cases.md",
         "29ec5c36-Batch_4_15_cases.md","83b17139-Batch_5_15_cases.md"]

# --- parse packet: id -> verbatim saved answer -------------------------------
cases={}
for b in BATCH:
    txt=(UP/b).read_text()
    for m in re.finditer(r"^## (AUDIT-\d{3})\n(.*?)(?=^## AUDIT-\d{3}\n|\Z)", txt, re.S|re.M):
        cid, body = m.group(1), m.group(2)
        sa=re.search(r"### Saved answer \(verbatim\)\n\n~~~~text\n(.*?)\n~~~~\n", body, re.S)
        cases[cid]=sa.group(1)
print("parsed cases:", len(cases))

HTML_IDS=["AUDIT-002","AUDIT-009","AUDIT-013","AUDIT-016","AUDIT-026",
          "AUDIT-029","AUDIT-038","AUDIT-042","AUDIT-074"]

outdir=pathlib.Path("render2"); outdir.mkdir(exist_ok=True)
DOC_START=re.compile(r"<!doctype html", re.I)

results={}
with sync_playwright() as p:
    br=p.chromium.launch()
    for cid in HTML_IDS:
        raw=cases[cid]
        verbatim=outdir/f"{cid}_verbatim.html"; verbatim.write_text(raw)
        m=DOC_START.search(raw)
        extracted_src = raw[m.start():] if m else raw
        extracted=outdir/f"{cid}_extracted.html"; extracted.write_text(extracted_src)
        rec={"sha256_saved_answer":hashlib.sha256(raw.encode()).hexdigest()[:16],
             "prose_before_doctype": raw[:m.start()].strip() if m and m.start()>0 else "",
             "bytes_stripped": m.start() if m else 0}
        for mode,path in (("verbatim",verbatim),("extracted",extracted)):
            pg=br.new_page()
            pg.goto("file://"+str(path.resolve()))
            body=pg.locator("body").inner_text()
            r={"title":pg.title(),
               "h1_count":pg.locator("h1").count(),
               "h1_text":pg.locator("h1").first.inner_text() if pg.locator("h1").count() else None,
               "details_anchor_present":pg.locator("a[href='#details']").count(),
               "details_target_present":pg.locator("#details").count(),
               "date_visible":"2026-10-12" in body,
               "room_visible":"Room 4" in body,
               "scripts":pg.locator("script").count(),
               "imgs":pg.locator("img").count(),
               "ext_resources":pg.evaluate("()=>document.querySelectorAll('link[href],script[src],img[src]').length"),
               "visible_text_first_120":body.strip()[:120].replace("\n"," | "),
               "stray_prose_rendered": None}
            if pg.locator("a[href='#details']").count():
                pg.click("a[href='#details']"); r["hash_after_click"]=pg.evaluate("()=>location.hash")
            else:
                r["hash_after_click"]=None
            # is commentary visible on the page?
            r["stray_prose_rendered"] = bool(rec["prose_before_doctype"]) and \
                any(w in body for w in ["prior response","requirements","Checking","corrections"])
            pg.screenshot(path=str(outdir/f"{cid}_{mode}.png"), full_page=True)
            pg.close()
            rec[mode]=r
        results[cid]=rec
    br.close()

pathlib.Path("render2/render_log.json").write_text(json.dumps(results,indent=2))
for cid,rec in results.items():
    v,e=rec["verbatim"],rec["extracted"]
    print(f"{cid}: stripped={rec['bytes_stripped']:4d}B | verbatim: h1={v['h1_count']} title={v['title']!r} strayprose={v['stray_prose_rendered']} anchor={v['hash_after_click']} | extracted: h1={e['h1_count']} anchor={e['hash_after_click']}")
