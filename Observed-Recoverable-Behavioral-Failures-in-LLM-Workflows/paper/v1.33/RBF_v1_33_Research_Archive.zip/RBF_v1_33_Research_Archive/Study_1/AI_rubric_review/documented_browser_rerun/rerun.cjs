const fs=require('fs'),path=require('path'),crypto=require('crypto'),{execFileSync}=require('child_process');
const {chromium}=require(process.env.PLAYWRIGHT_MODULE||'playwright');
const root=__dirname, packet=path.resolve(process.argv[2]||path.join(__dirname,'../masked_packet/All_75_cases.json'));
const browserPath=process.env.RBF_BROWSER||'/Applications/Google Chrome.app/Contents/MacOS/Google Chrome';
const ids=['002','009','013','016','026','029','038','042','074'].map(x=>'AUDIT-'+x);
const all=JSON.parse(fs.readFileSync(packet)),hash=s=>crypto.createHash('sha256').update(s).digest('hex');
(async()=>{const browser=await chromium.launch({executablePath:browserPath,headless:true});
const log={timestamp_utc:new Date().toISOString(),browser_product:'Google Chrome (Chromium-based), headless',browser_version:browser.version(),command_version:execFileSync(browserPath,['--version'],{encoding:'utf8'}).trim(),platform:process.platform,viewport:{width:800,height:600},device_scale_factor:1,network:'HTTP and HTTPS blocked',records:{}};
for(const id of ids){const c=all.find(c=>c.id===id),raw=c.saved_answer,start=raw.search(/<!doctype html/i);if(start<0)throw Error('doctype missing '+id);
 const rec={sha256_saved_answer:hash(raw),prefix:raw.slice(0,start),characters_removed:start,utf8_bytes_removed:Buffer.byteLength(raw.slice(0,start)),modes:{}};
 for(const mode of ['verbatim','extracted']){const source=mode==='verbatim'?raw:raw.slice(start),file=path.join(root,id+'_'+mode+'.html');fs.writeFileSync(file,source);
 const pg=await browser.newPage({viewport:log.viewport,deviceScaleFactor:1});await pg.route(/^https?:/,r=>r.abort());await pg.goto('file://'+file);
 const body=await pg.locator('body').innerText(),h1=pg.locator('h1'),a=pg.locator('a[href="#details"]');
 const prefixNorm=rec.prefix.replace(/\s+/g,' ').trim(),bodyNorm=body.replace(/\s+/g,' ').trim();
 const r={source_sha256:hash(source),title:await pg.title(),h1_count:await h1.count(),h1_text:await h1.first().innerText(),details_link_count:await a.count(),details_target_count:await pg.locator('#details').count(),date_present:body.includes('2026-10-12'),room_present:body.includes('Room 4'),script_count:await pg.locator('script').count(),image_count:await pg.locator('img').count(),external_resource_elements:await pg.locator('link[href],script[src],img[src]').count(),body_text:body,prefix_rendered:!!prefixNorm&&bodyNorm.startsWith(prefixNorm)};
 await pg.screenshot({path:path.join(root,id+'_'+mode+'.png'),fullPage:true});
 if(await a.count()){await a.first().click();r.hash_after_click=await pg.evaluate(()=>location.hash);}rec.modes[mode]=r;await pg.close();
 }
 log.records[id]=rec;
}
await browser.close();fs.writeFileSync(path.join(root,'rerun_log.json'),JSON.stringify(log,null,2));console.log(JSON.stringify({browser:log.command_version,cases:ids.length,commentary:Object.entries(log.records).filter(([k,v])=>v.modes.verbatim.prefix_rendered).map(([k])=>k)}));
})().catch(e=>{console.error(e);process.exit(1)});
