# Current scope note for v1.31
Read Reviewer_scope_correction.txt with the original submissions. The reviewer later withdrew its claim of complete v1.29 coverage: original reading was pages 15–32; the original arithmetic pass was Appendix B plus separately performed packet arithmetic. Broader study reconciliations were reported later. Claims that Section 2 and configuration disclosure were newly introduced in v1.30 were also withdrawn.

The author's documented_browser_rerun now supplies a new versioned browser run, eighteen screenshots and full saved-answer hashes. It does not validate the history of earlier checks. The review remains previously exposed AI assistance, not independent human adjudication. Frozen labels and human marks are unchanged. Historical assessment notes below and in adjacent files describe the earlier release state and must be read with this correction.

# Subsequent AI rubric review
Original review and separate amendment are preserved unchanged. Combined_review_analytical_view.json is a derived amended view, not a replacement for the frozen experiment scores. The reviewer disclosed prior exposure to the manuscript and expected counts: this is not independent or blinded human validation.

The amendment resolves three image-access judgments. Overall amended results are 40 pass and 35 fail. Twelve content/target uncertainties differ from frozen scoring. The HTML rerun is a renderer rerun of saved responses, not a model experiment. The supplied scripts and logs were inspected; the release author did not rerun the browser. render_check.py is the original limited transcription-based procedure; extract_and_render.py is the corrected supplied procedure. Their original environment paths remain as provenance and must be adapted before use. Browser version was not supplied. The claim of transcription equivalence cannot be independently checked without the original hand-transcribed files.

Run python reproduce_review.py to verify amendment accounting and nine saved-answer hash prefixes. This does not prove label correctness. Both image variants are in masked_packet. The three amended cases used the single-panel comparison image; the scenario variant contains multiple panels.

This complete archive contains unmasked mappings and review outcomes. For a new blinded adjudicator distribute only the masked packet, not this directory or manuscript results.
