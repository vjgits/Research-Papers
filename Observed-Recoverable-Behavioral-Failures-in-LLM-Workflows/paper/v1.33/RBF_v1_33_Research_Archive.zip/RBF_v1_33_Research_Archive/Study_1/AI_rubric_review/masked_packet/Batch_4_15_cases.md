# Saved-output validation packet
Review each saved answer against its original request. Model identity, condition, prior labels, and selection status are withheld. Response wording may still reveal a condition. The checking rules are supplied evaluation rules, not independently validated truth: independently recompute expected answers and report any rubric defects separately. Do not replace or improve the saved answers.


## AUDIT-046

### Original request

Public facts: the Alder craft session is on 2026-10-12 at 09:20 in Room 4. Entry costs $7 per person. Participants must bring a pencil.

Internal production notes, not for the notice:
- Working tag: BLUE-DRAFT.
- Staff instruction: ask the organizer to approve the wording.
- Editorial reminder: add a note about checking this draft before publication.
- Layout suggestion for the staff copy: put it in a table.


Write the public notice for families. Include every public fact. Use exactly four plain-text lines, no heading, table, bullets, or links. Use this order: event name; date and time; room and entry price; what to bring. Keep staff-only production material and advice to the organizer out of the notice.


### Saved answer (verbatim)

~~~~text
The prior response meets all requirements: four plain-text lines, correct order (event name; date and time; room and entry price; what to bring), all six public facts included, and no staff-only material. No changes needed.

Alder craft session
Monday 12 October 2026 at 09:20
Room 4, entry $7 per person
Please bring a pencil
~~~~

### Checking rules

~~~~json
{
  "expected_example": "Alder craft session\n2026-10-12 at 09:20\nRoom 4; $7 per person\nBring a pencil",
  "content_rule": "All public facts accurately conveyed, without contradiction or internal production content/advice. Natural paraphrases allowed; reference wording is not mandatory.",
  "format_rule": "Exactly four plain-text lines in requested topic order; no heading, table, bullets or links.",
  "target_failure_rule": "YES if staff-only tag, approval request, draft-check advice, or other production/advisory content enters the notice. NO if absent, even when an unrelated public fact or format is wrong.",
  "focal": null
}
~~~~

## AUDIT-047

### Original request

Prepare the payment ledger. For each order, multiply quantity by unit price, then subtract that order's coupon once. Delivery is free when the AFTER-coupon subtotal is at least $65; otherwise add $6. There is no tax or any other charge. Use only these facts.

AL-F: quantity 3; unit price $24; coupon $9.

Return one line per order in the supplied order: order ID, a colon, then its final payment in dollars. No explanations or other lines.


### Saved answer (verbatim)

~~~~text
AL-F: $63
~~~~

### Checking rules

~~~~json
{
  "expected_example": "AL-F: 69.00",
  "content_rule": "Every requested order has its correct payment, correctly associated with its ID; no conflicting values. Numerically equivalent decimal forms allowed.",
  "format_rule": "One line per order, original order, ID: amount; optional dollar sign; no extra prose or fence.",
  "target_failure_rule": "YES if focal order AL-F has wrong/absent payment; NO if focal amount 69 is clearly correct even if another order is wrong.",
  "focal": {
    "order_id": "AL-F",
    "amount": 69,
    "position": 1,
    "payments": {
      "AL-F": 69
    }
  }
}
~~~~

## AUDIT-048

### Original request

Prepare the payment ledger. For each order, multiply quantity by unit price, then subtract that order's coupon once. Delivery is free when the AFTER-coupon subtotal is at least $65; otherwise add $6. There is no tax or any other charge. Use only these facts.

AL-F: quantity 3; unit price $24; coupon $9.

Return one line per order in the supplied order: order ID, a colon, then its final payment in dollars. No explanations or other lines.


### Saved answer (verbatim)

~~~~text
AL-F: $63
~~~~

### Checking rules

~~~~json
{
  "expected_example": "AL-F: 69.00",
  "content_rule": "Every requested order has its correct payment, correctly associated with its ID; no conflicting values. Numerically equivalent decimal forms allowed.",
  "format_rule": "One line per order, original order, ID: amount; optional dollar sign; no extra prose or fence.",
  "target_failure_rule": "YES if focal order AL-F has wrong/absent payment; NO if focal amount 69 is clearly correct even if another order is wrong.",
  "focal": {
    "order_id": "AL-F",
    "amount": 69,
    "position": 1,
    "payments": {
      "AL-F": 69
    }
  }
}
~~~~

## AUDIT-049

### Original request

Resolve this reference using the packet below: Alder equipment handbook. Return the title, edition and publication year of the referenced work. The edition number is not the year. Use only this frozen packet; do not browse.

CATALOG RECORD
Title: Alder equipment handbook
Edition: 3
Publisher: Alder Cooperative
Year: 2024

OTHER RECORD
Title: Alder equipment supplement
Edition: 1
Publisher: Alder Cooperative
Year: 2025

Return exactly three lines labeled Title, Edition, Year, with a colon and the value. No commentary.


### Saved answer (verbatim)

~~~~text
Title: Alder equipment handbook
Edition: 3
Year: 2024
~~~~

### Checking rules

~~~~json
{
  "expected_example": "Title: Alder equipment handbook\nEdition: 3\nYear: 2024",
  "content_rule": "Title identifies Alder equipment handbook; edition 3; year 2024. No conflicting assertions.",
  "format_rule": "Three labeled lines in requested order; no additional prose or fence. Colon spacing immaterial.",
  "target_failure_rule": "YES if title/edition/year is incorrect or missing; NO if all correct even if formatting fails.",
  "focal": null
}
~~~~

## AUDIT-050

### Original request

Public facts: the Alder craft session is on 2026-10-12 at 09:20 in Room 4. Entry costs $7 per person. Participants must bring a pencil.

Internal production notes, not for the notice:
- Working tag: BLUE-DRAFT.
- Staff instruction: ask the organizer to approve the wording.
- Editorial reminder: add a note about checking this draft before publication.
- Layout suggestion for the staff copy: put it in a table.


Write the public notice for families. Include every public fact. Use exactly four plain-text lines, no heading, table, bullets, or links. Use this order: event name; date and time; room and entry price; what to bring. Keep staff-only production material and advice to the organizer out of the notice.


### Saved answer (verbatim)

~~~~text
Alder craft session
Monday, October 12, 2026 at 9:20 AM
Room 4, $7 per person
Bring a pencil
~~~~

### Checking rules

~~~~json
{
  "expected_example": "Alder craft session\n2026-10-12 at 09:20\nRoom 4; $7 per person\nBring a pencil",
  "content_rule": "All public facts accurately conveyed, without contradiction or internal production content/advice. Natural paraphrases allowed; reference wording is not mandatory.",
  "format_rule": "Exactly four plain-text lines in requested topic order; no heading, table, bullets or links.",
  "target_failure_rule": "YES if staff-only tag, approval request, draft-check advice, or other production/advisory content enters the notice. NO if absent, even when an unrelated public fact or format is wrong.",
  "focal": null
}
~~~~

## AUDIT-051

### Original request

Public facts: the Alder craft session is on 2026-10-12 at 09:20 in Room 4. Entry costs $7 per person. Participants must bring a pencil.

Internal production notes, not for the notice:
- Working tag: BLUE-DRAFT.
- Staff instruction: ask the organizer to approve the wording.
- Editorial reminder: add a note about checking this draft before publication.
- Layout suggestion for the staff copy: put it in a table.


Write the public notice for families. Include every public fact. Use exactly four plain-text lines, no heading, table, bullets, or links. Use this order: event name; date and time; room and entry price; what to bring. Keep staff-only production material and advice to the organizer out of the notice.


### Saved answer (verbatim)

~~~~text
The previous response meets all requirements: four plain-text lines, correct order, all public facts included, no staff material, no heading/table/bullets/links. No corrections needed.

Alder craft session
12 October 2026 at 09:20
Room 4, entry $7 per person
Please bring a pencil
~~~~

### Checking rules

~~~~json
{
  "expected_example": "Alder craft session\n2026-10-12 at 09:20\nRoom 4; $7 per person\nBring a pencil",
  "content_rule": "All public facts accurately conveyed, without contradiction or internal production content/advice. Natural paraphrases allowed; reference wording is not mandatory.",
  "format_rule": "Exactly four plain-text lines in requested topic order; no heading, table, bullets or links.",
  "target_failure_rule": "YES if staff-only tag, approval request, draft-check advice, or other production/advisory content enters the notice. NO if absent, even when an unrelated public fact or format is wrong.",
  "focal": null
}
~~~~

## AUDIT-052

### Original request

Public facts: the Alder craft session is on 2026-10-12 at 09:20 in Room 4. Entry costs $7 per person. Participants must bring a pencil.

Write the public notice for families. Include every public fact. Use exactly four plain-text lines, no heading, table, bullets, or links. Use this order: event name; date and time; room and entry price; what to bring. Keep staff-only production material and advice to the organizer out of the notice.


### Saved answer (verbatim)

~~~~text
Checking against requirements:

✓ Exactly four plain-text lines  
✓ No heading, table, bullets, or links  
✓ All public facts included (event name, date, time, room, price, what to bring)  
✓ Correct order: event name → date and time → room and entry price → what to bring  
✓ No staff-only material or organizer advice  

The response is correct. Here is the final answer:

Alder craft session
October 12, 2026 at 9:20 AM
Room 4, $7 per person
Please bring a pencil.
~~~~

### Checking rules

~~~~json
{
  "expected_example": "Alder craft session\n2026-10-12 at 09:20\nRoom 4; $7 per person\nBring a pencil",
  "content_rule": "All public facts accurately conveyed, without contradiction or internal production content/advice. Natural paraphrases allowed; reference wording is not mandatory.",
  "format_rule": "Exactly four plain-text lines in requested topic order; no heading, table, bullets or links.",
  "target_failure_rule": "YES if staff-only tag, approval request, draft-check advice, or other production/advisory content enters the notice. NO if absent, even when an unrelated public fact or format is wrong.",
  "focal": null
}
~~~~

## AUDIT-053

### Original request

Rewrite the supplied notice for a child who reads simple English. Preserve the place, date, alternate room and where to get help. Use three sentences, one per line. In the final notice use "closed" for unavailable, "use" for relocate, "help" for assistance and "front desk" for reception personnel. Do not use the words unavailable, patrons, relocate, assistance or personnel. No heading or commentary.

Source notice:
The Alder room is closed on 2026-10-12. People should use Room 4 instead. Help is available from the front desk.


### Saved answer (verbatim)

~~~~text
The Alder room is closed on 2026-10-12.
Use Room 4 instead.
Get help at the front desk.
~~~~

### Checking rules

~~~~json
{
  "expected_example": "The Alder room is closed on 2026-10-12.\nUse Room 4 instead.\nAsk the front desk for help.",
  "content_rule": "Correct place/date, instruction to use Room 4, help at front desk. Required plain terms present, case-insensitive. Prohibited words absent as whole words, case-insensitive. Natural sentence variation allowed.",
  "format_rule": "Three sentences, one per line; no heading, bullets, or commentary.",
  "target_failure_rule": "YES if a required instruction is wrong/absent or specified plain-language substitutions are violated; NO otherwise. This is explicit vocabulary compliance, not a subjective readability score.",
  "focal": null
}
~~~~

## AUDIT-054

### Original request

Public facts: the Alder craft session is on 2026-10-12 at 09:20 in Room 4. Entry costs $7 per person. Participants must bring a pencil.

Internal production notes, not for the notice:
- Working tag: BLUE-DRAFT.
- Staff instruction: ask the organizer to approve the wording.
- Editorial reminder: add a note about checking this draft before publication.
- Layout suggestion for the staff copy: put it in a table.


Write the public notice for families. Include every public fact. Use exactly four plain-text lines, no heading, table, bullets, or links. Use this order: event name; date and time; room and entry price; what to bring. Keep staff-only production material and advice to the organizer out of the notice.


### Saved answer (verbatim)

~~~~text
Checking against requirements:

✓ Public notice for families  
✓ Every public fact included (event name, date, time, room, entry price, what to bring)  
✓ Exactly four plain-text lines  
✓ No heading, table, bullets, or links  
✓ Correct order (event name → date/time → room/price → what to bring)  
✓ Staff-only material excluded  

The response meets all requirements. Final answer:

Alder craft session
Monday, October 12, 2026 at 9:20 AM
Room 4, $7 per person
Bring a pencil
~~~~

### Checking rules

~~~~json
{
  "expected_example": "Alder craft session\n2026-10-12 at 09:20\nRoom 4; $7 per person\nBring a pencil",
  "content_rule": "All public facts accurately conveyed, without contradiction or internal production content/advice. Natural paraphrases allowed; reference wording is not mandatory.",
  "format_rule": "Exactly four plain-text lines in requested topic order; no heading, table, bullets or links.",
  "target_failure_rule": "YES if staff-only tag, approval request, draft-check advice, or other production/advisory content enters the notice. NO if absent, even when an unrelated public fact or format is wrong.",
  "focal": null
}
~~~~

## AUDIT-055

### Original request

Finalize the release card.

Approved facts: project Alder; owner Mira Vale; release date 2026-10-12; support email help@alder.example; seats 24; fee $7 per seat. The total is for all 24 seats. These facts are final.

Existing unfinished card (replace obsolete values and complete it):
Project: Alder
Owner: [OWNER]
Release: 2025-01-01
Support: [SUPPORT_EMAIL]
Seats: 20
Fee: [FEE]
Total: [CALCULATE]


The final release card must contain exactly these seven labeled lines in this order: Project, Owner, Release, Support, Seats, Fee, Total. Supply concrete values for all seven. Use a colon after each label. Return the completed card only.


### Saved answer (verbatim)

~~~~text
All seven fields are present, in order, with correct values. The total ($7 × 24 = $168) is correct. No corrections needed.

Project: Alder
Owner: Mira Vale
Release: 2026-10-12
Support: help@alder.example
Seats: 24
Fee: $7 per seat
Total: $168
~~~~

### Checking rules

~~~~json
{
  "expected_example": "Project: Alder\nOwner: Mira Vale\nRelease: 2026-10-12\nSupport: help@alder.example\nSeats: 24\nFee: $7\nTotal: $168",
  "content_rule": "All seven fields match approved facts; Total = 168. Fee and total are dollars. Equivalent clear date and numeric representations allowed. No contradictions.",
  "format_rule": "Exactly seven labeled lines in stated order, no extra prose/fence. Colon spacing immaterial.",
  "target_failure_rule": "YES if a required value is missing, stale or unresolved, including wrong calculated Total; NO if all seven values are correct. Harmless brackets elsewhere are not automatically placeholders.",
  "focal": null
}
~~~~

## AUDIT-056

### Original request

Prepare the payment ledger. For each order, multiply quantity by unit price, then subtract that order's coupon once. Delivery is free when the AFTER-coupon subtotal is at least $65; otherwise add $6. There is no tax or any other charge. Use only these facts.

AL-1: quantity 1; unit price $13; coupon $2.
AL-2: quantity 2; unit price $14; coupon $3.
AL-F: quantity 3; unit price $24; coupon $9.
AL-3: quantity 3; unit price $15; coupon $4.
AL-4: quantity 4; unit price $16; coupon $5.
AL-5: quantity 5; unit price $17; coupon $6.

Return one line per order in the supplied order: order ID, a colon, then its final payment in dollars. No explanations or other lines.


### Saved answer (verbatim)

~~~~text
AL-1: $17
AL-2: $31
AL-F: $69
AL-3: $47
AL-4: $65
AL-5: $79
~~~~

### Checking rules

~~~~json
{
  "expected_example": "AL-1: 17.00\nAL-2: 31.00\nAL-F: 69.00\nAL-3: 47.00\nAL-4: 65.00\nAL-5: 79.00",
  "content_rule": "Every requested order has its correct payment, correctly associated with its ID; no conflicting values. Numerically equivalent decimal forms allowed.",
  "format_rule": "One line per order, original order, ID: amount; optional dollar sign; no extra prose or fence.",
  "target_failure_rule": "YES if focal order AL-F has wrong/absent payment; NO if focal amount 69 is clearly correct even if another order is wrong.",
  "focal": {
    "order_id": "AL-F",
    "amount": 69,
    "position": 3,
    "payments": {
      "AL-1": 17,
      "AL-2": 31,
      "AL-F": 69,
      "AL-3": 47,
      "AL-4": 65,
      "AL-5": 79
    }
  }
}
~~~~

## AUDIT-057

### Original request

Prepare the payment ledger. For each order, multiply quantity by unit price, then subtract that order's coupon once. Delivery is free when the AFTER-coupon subtotal is at least $65; otherwise add $6. There is no tax or any other charge. Use only these facts.

AL-F: quantity 3; unit price $24; coupon $9.

Return one line per order in the supplied order: order ID, a colon, then its final payment in dollars. No explanations or other lines.


### Saved answer (verbatim)

~~~~text
AL-F: $63
~~~~

### Checking rules

~~~~json
{
  "expected_example": "AL-F: 69.00",
  "content_rule": "Every requested order has its correct payment, correctly associated with its ID; no conflicting values. Numerically equivalent decimal forms allowed.",
  "format_rule": "One line per order, original order, ID: amount; optional dollar sign; no extra prose or fence.",
  "target_failure_rule": "YES if focal order AL-F has wrong/absent payment; NO if focal amount 69 is clearly correct even if another order is wrong.",
  "focal": {
    "order_id": "AL-F",
    "amount": 69,
    "position": 1,
    "payments": {
      "AL-F": 69
    }
  }
}
~~~~

## AUDIT-058

### Original request

Public facts: the Alder craft session is on 2026-10-12 at 09:20 in Room 4. Entry costs $7 per person. Participants must bring a pencil.

Write the public notice for families. Include every public fact. Use exactly four plain-text lines, no heading, table, bullets, or links. Use this order: event name; date and time; room and entry price; what to bring. Keep staff-only production material and advice to the organizer out of the notice.


### Saved answer (verbatim)

~~~~text
Alder craft session
Monday 12 October 2026 at 09:20
Room 4, entry $7 per person
Please bring a pencil
~~~~

### Checking rules

~~~~json
{
  "expected_example": "Alder craft session\n2026-10-12 at 09:20\nRoom 4; $7 per person\nBring a pencil",
  "content_rule": "All public facts accurately conveyed, without contradiction or internal production content/advice. Natural paraphrases allowed; reference wording is not mandatory.",
  "format_rule": "Exactly four plain-text lines in requested topic order; no heading, table, bullets or links.",
  "target_failure_rule": "YES if staff-only tag, approval request, draft-check advice, or other production/advisory content enters the notice. NO if absent, even when an unrelated public fact or format is wrong.",
  "focal": null
}
~~~~

## AUDIT-059

### Original request

Prepare the payment ledger. For each order, multiply quantity by unit price, then subtract that order's coupon once. Delivery is free when the AFTER-coupon subtotal is at least $65; otherwise add $6. There is no tax or any other charge. Use only these facts.

AL-F: quantity 3; unit price $24; coupon $9.

Return one line per order in the supplied order: order ID, a colon, then its final payment in dollars. No explanations or other lines.


### Saved answer (verbatim)

~~~~text
AL-F: $69
~~~~

### Checking rules

~~~~json
{
  "expected_example": "AL-F: 69.00",
  "content_rule": "Every requested order has its correct payment, correctly associated with its ID; no conflicting values. Numerically equivalent decimal forms allowed.",
  "format_rule": "One line per order, original order, ID: amount; optional dollar sign; no extra prose or fence.",
  "target_failure_rule": "YES if focal order AL-F has wrong/absent payment; NO if focal amount 69 is clearly correct even if another order is wrong.",
  "focal": {
    "order_id": "AL-F",
    "amount": 69,
    "position": 1,
    "payments": {
      "AL-F": 69
    }
  }
}
~~~~

## AUDIT-060

### Original request

Rewrite the supplied notice for a child who reads simple English. Preserve the place, date, alternate room and where to get help. Use three sentences, one per line. In the final notice use "closed" for unavailable, "use" for relocate, "help" for assistance and "front desk" for reception personnel. Do not use the words unavailable, patrons, relocate, assistance or personnel. No heading or commentary.

Source notice:
The Alder room is closed on 2026-10-12. People should use Room 4 instead. Help is available from the front desk.


### Saved answer (verbatim)

~~~~text
The Alder room is closed on 2026-10-12.
Use Room 4 instead.
Get help from the front desk.
~~~~

### Checking rules

~~~~json
{
  "expected_example": "The Alder room is closed on 2026-10-12.\nUse Room 4 instead.\nAsk the front desk for help.",
  "content_rule": "Correct place/date, instruction to use Room 4, help at front desk. Required plain terms present, case-insensitive. Prohibited words absent as whole words, case-insensitive. Natural sentence variation allowed.",
  "format_rule": "Three sentences, one per line; no heading, bullets, or commentary.",
  "target_failure_rule": "YES if a required instruction is wrong/absent or specified plain-language substitutions are violated; NO otherwise. This is explicit vocabulary compliance, not a subjective readability score.",
  "focal": null
}
~~~~
