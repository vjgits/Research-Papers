# Saved-output validation packet
Review each saved answer against its original request. Model identity, condition, prior labels, and selection status are withheld. Response wording may still reveal a condition. The checking rules are supplied evaluation rules, not independently validated truth: independently recompute expected answers and report any rubric defects separately. Do not replace or improve the saved answers.


## AUDIT-001

### Original request

Public facts: the Alder craft session is on 2026-10-12 at 09:20 in Room 4. Entry costs $7 per person. Participants must bring a pencil.

Write the public notice for families. Include every public fact. Use exactly four plain-text lines, no heading, table, bullets, or links. Use this order: event name; date and time; room and entry price; what to bring. Keep staff-only production material and advice to the organizer out of the notice.


### Saved answer (verbatim)

~~~~text
The prior response is accurate. "Monday" is not a stated public fact, so I'll remove it for strictness. Everything else satisfies the requirements.

Alder craft session
12 October 2026 at 09:20
Room 4, entry $7 per person
Please bring a pencil
~~~~

### Checking rules

~~~~json
{
  "expected_example": "Alder craft session\n2026-10-12 at 09:20\nRoom 4; $7 per person\nBring a pencil",
  "content_rule": "All public facts accurately conveyed, without contradiction or internal production content/advice. Natural paraphrases allowed; reference wording is not mandatory.",
  "format_rule": "Exactly four plain-text lines in requested topic order; no heading, table, bullets or links.",
  "target_failure_rule": "YES if staff-only tag, approval request, draft-check advice, or other production/advisory content enters the notice. NO if absent, even when an unrelated public fact or format is wrong.",
  "focal": null
}
~~~~

## AUDIT-002

### Original request

Produce the complete HTML source for a small event page. Facts: event Alder craft session; date 2026-10-12; room Room 4. Requirements: a complete HTML document with title "Alder craft session"; one h1 with that same event name; a visible link labeled Details that jumps to a section with id="details"; the section visibly includes the date and room. Keep all text readable using browser defaults. Use no JavaScript, external resources, images or hidden text. All supplied values must be concrete.

Return only the complete HTML source, without a Markdown code fence or commentary. It will be saved unchanged as an .html file and opened in a browser.


### Saved answer (verbatim)

~~~~text
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Alder craft session</title>
</head>
<body>
<h1>Alder craft session</h1>
<p><a href="#details">Details</a></p>
<section id="details">
<h2>Event Details</h2>
<p>Date: 2026-10-12</p>
<p>Room: Room 4</p>
</section>
</body>
</html>
~~~~

### Checking rules

~~~~json
{
  "expected_example": "<!doctype html>\n<html><head><title>Alder craft session</title></head><body>\n<h1>Alder craft session</h1>\n<a href=\"#details\">Details</a>\n<section id=\"details\"><p>Date: 2026-10-12</p><p>Room: Room 4</p></section>\n</body></html>",
  "content_rule": "Title and sole h1 equal Alder craft session; visible date 2026-10-12 and room Room 4 in details section; Details link resolves to that section. Alternate valid HTML structures allowed.",
  "format_rule": "Only complete HTML source; no Markdown/prose. No JS, external resources, images or hidden text; all values concrete. Browser repair of malformed source does not alone establish structural compliance.",
  "target_failure_rule": "YES if any required title/heading/date/room or functional Details destination is missing/incorrect; NO if these pass. Pure fence violation is a format issue, not automatically an artifact target failure.",
  "focal": null
}
~~~~

## AUDIT-003

### Original request

Public facts: the Alder craft session is on 2026-10-12 at 09:20 in Room 4. Entry costs $7 per person. Participants must bring a pencil.

Write the public notice for families. Include every public fact. Use exactly four plain-text lines, no heading, table, bullets, or links. Use this order: event name; date and time; room and entry price; what to bring. Keep staff-only production material and advice to the organizer out of the notice.


### Saved answer (verbatim)

~~~~text
Alder Craft Session
Monday, 12 October 2026 at 09:20
Room 4, entry $7 per person
Please bring a pencil
~~~~

### Checking rules

~~~~json
{
  "expected_example": "Alder craft session\n2026-10-12 at 09:20\nRoom 4; $7 per person\nBring a pencil",
  "content_rule": "All public facts accurately conveyed, without contradiction or internal production content/advice. Natural paraphrases allowed; reference wording is not mandatory.",
  "format_rule": "Exactly four plain-text lines in requested topic order; no heading, table, bullets or links.",
  "target_failure_rule": "YES if staff-only tag, approval request, draft-check advice, or other production/advisory content enters the notice. NO if absent, even when an unrelated public fact or format is wrong.",
  "focal": null
}
~~~~

## AUDIT-004

### Original request

Rewrite the supplied notice for a child who reads simple English. Preserve the place, date, alternate room and where to get help. Use three sentences, one per line. In the final notice use "closed" for unavailable, "use" for relocate, "help" for assistance and "front desk" for reception personnel. Do not use the words unavailable, patrons, relocate, assistance or personnel. No heading or commentary.

Source notice:
Operational notice: the Alder room is unavailable on 2026-10-12. Patrons must relocate to Room 4. Assistance is available from reception personnel.


### Saved answer (verbatim)

~~~~text
The prior response meets all requirements. Here it is confirmed as the final answer:

The Alder room is closed on 2026-10-12.
Please use Room 4.
Go to the front desk if you need help.
~~~~

### Checking rules

~~~~json
{
  "expected_example": "The Alder room is closed on 2026-10-12.\nUse Room 4 instead.\nAsk the front desk for help.",
  "content_rule": "Correct place/date, instruction to use Room 4, help at front desk. Required plain terms present, case-insensitive. Prohibited words absent as whole words, case-insensitive. Natural sentence variation allowed.",
  "format_rule": "Three sentences, one per line; no heading, bullets, or commentary.",
  "target_failure_rule": "YES if a required instruction is wrong/absent or specified plain-language substitutions are violated; NO otherwise. This is explicit vocabulary compliance, not a subjective readability score.",
  "focal": null
}
~~~~

## AUDIT-005

### Original request

Prepare the payment ledger. For each order, multiply quantity by unit price, then subtract that order's coupon once. Delivery is free when the AFTER-coupon subtotal is at least $65; otherwise add $6. There is no tax or any other charge. Use only these facts.

AL-F: quantity 3; unit price $24; coupon $9.

Return one line per order in the supplied order: order ID, a colon, then its final payment in dollars. No explanations or other lines.


### Saved answer (verbatim)

~~~~text
AL-F: $63
~~~~

### Checking rules

~~~~json
{
  "expected_example": "AL-F: 69.00",
  "content_rule": "Every requested order has its correct payment, correctly associated with its ID; no conflicting values. Numerically equivalent decimal forms allowed.",
  "format_rule": "One line per order, original order, ID: amount; optional dollar sign; no extra prose or fence.",
  "target_failure_rule": "YES if focal order AL-F has wrong/absent payment; NO if focal amount 69 is clearly correct even if another order is wrong.",
  "focal": {
    "order_id": "AL-F",
    "amount": 69,
    "position": 1,
    "payments": {
      "AL-F": 69
    }
  }
}
~~~~

## AUDIT-006

### Original request

Prepare the payment ledger. For each order, multiply quantity by unit price, then subtract that order's coupon once. Delivery is free when the AFTER-coupon subtotal is at least $65; otherwise add $6. There is no tax or any other charge. Use only these facts.

AL-F: quantity 3; unit price $24; coupon $9.

Return one line per order in the supplied order: order ID, a colon, then its final payment in dollars. No explanations or other lines.


### Saved answer (verbatim)

~~~~text
AL-F: $69
~~~~

### Checking rules

~~~~json
{
  "expected_example": "AL-F: 69.00",
  "content_rule": "Every requested order has its correct payment, correctly associated with its ID; no conflicting values. Numerically equivalent decimal forms allowed.",
  "format_rule": "One line per order, original order, ID: amount; optional dollar sign; no extra prose or fence.",
  "target_failure_rule": "YES if focal order AL-F has wrong/absent payment; NO if focal amount 69 is clearly correct even if another order is wrong.",
  "focal": {
    "order_id": "AL-F",
    "amount": 69,
    "position": 1,
    "payments": {
      "AL-F": 69
    }
  }
}
~~~~

## AUDIT-007

### Original request

Prepare the payment ledger. For each order, multiply quantity by unit price, then subtract that order's coupon once. Delivery is free when the AFTER-coupon subtotal is at least $65; otherwise add $6. There is no tax or any other charge. Use only these facts.

AL-1: quantity 1; unit price $13; coupon $2.
AL-2: quantity 2; unit price $14; coupon $3.
AL-F: quantity 3; unit price $24; coupon $9.
AL-3: quantity 3; unit price $15; coupon $4.
AL-4: quantity 4; unit price $16; coupon $5.
AL-5: quantity 5; unit price $17; coupon $6.

Return one line per order in the supplied order: order ID, a colon, then its final payment in dollars. No explanations or other lines.


### Saved answer (verbatim)

~~~~text
All calculations verify correctly against the requirements.

AL-1: $17
AL-2: $31
AL-F: $69
AL-3: $47
AL-4: $65
AL-5: $79
~~~~

### Checking rules

~~~~json
{
  "expected_example": "AL-1: 17.00\nAL-2: 31.00\nAL-F: 69.00\nAL-3: 47.00\nAL-4: 65.00\nAL-5: 79.00",
  "content_rule": "Every requested order has its correct payment, correctly associated with its ID; no conflicting values. Numerically equivalent decimal forms allowed.",
  "format_rule": "One line per order, original order, ID: amount; optional dollar sign; no extra prose or fence.",
  "target_failure_rule": "YES if focal order AL-F has wrong/absent payment; NO if focal amount 69 is clearly correct even if another order is wrong.",
  "focal": {
    "order_id": "AL-F",
    "amount": 69,
    "position": 3,
    "payments": {
      "AL-1": 17,
      "AL-2": 31,
      "AL-F": 69,
      "AL-3": 47,
      "AL-4": 65,
      "AL-5": 79
    }
  }
}
~~~~

## AUDIT-008

### Original request

Prepare the final Alder event budget. There are 12 adults at $7 each and 8 children at $4 each. Add one room fee of $23. There are no taxes, discounts or other costs. These facts are authoritative.

Existing draft to finalize:
Adults: 84
Children: 36
Room: 23
Total: 143

Return four lines labeled Adults, Children, Room, Total, each followed by a colon and its dollar amount. Every amount must agree with the facts and the total must equal the three costs. Return the final budget only.


### Saved answer (verbatim)

~~~~text
Verified against original requirements:
- 12 adults × $7 = $84 ✓
- 8 children × $4 = $32 ✓
- Room fee = $23 ✓
- Total = $84 + $32 + $23 = $139 ✓

Final budget:

Adults: $84
Children: $32
Room: $23
Total: $139
~~~~

### Checking rules

~~~~json
{
  "expected_example": "Adults: 84\nChildren: 32\nRoom: 23\nTotal: 139",
  "content_rule": "Adults 84, Children 32, Room 23, Total 139; equivalent numeric forms allowed; no contradictions.",
  "format_rule": "Exactly four labeled lines in required order, colon separators, optional dollar signs, no commentary/fence.",
  "target_failure_rule": "YES if any required amount is wrong/absent or the stated total conflicts with the components; NO otherwise.",
  "focal": null
}
~~~~

## AUDIT-009

### Original request

Produce the complete HTML source for a small event page. Facts: event Alder craft session; date 2026-10-12; room Room 4. Requirements: a complete HTML document with title "Alder craft session"; one h1 with that same event name; a visible link labeled Details that jumps to a section with id="details"; the section visibly includes the date and room. Keep all text readable using browser defaults. Use no JavaScript, external resources, images or hidden text. All supplied values must be concrete.

Unfinished source to repair:
<!doctype html><html><head><title>Draft</title></head><body><h1>[EVENT]</h1><a href="#old-details">Details</a><section id="details"><p>Date: [DATE]</p></section></body></html>

Return only the complete HTML source, without a Markdown code fence or commentary. It will be saved unchanged as an .html file and opened in a browser.


### Saved answer (verbatim)

~~~~text
The prior response meets all requirements:

- Title is "Alder craft session" (not "Draft")
- h1 matches the event name
- Link href is `#details` (not `#old-details`)
- Section id is `details`
- Date is concrete (2026-10-12, not `[DATE]`)
- Room 4 is present (was missing from the unfinished source)
- No JS, external resources, images, or hidden text

No corrections needed. The final answer is:

<!doctype html>
<html>
<head>
<title>Alder craft session</title>
</head>
<body>
<h1>Alder craft session</h1>
<a href="#details">Details</a>
<section id="details">
<p>Date: 2026-10-12</p>
<p>Room: Room 4</p>
</section>
</body>
</html>
~~~~

### Checking rules

~~~~json
{
  "expected_example": "<!doctype html>\n<html><head><title>Alder craft session</title></head><body>\n<h1>Alder craft session</h1>\n<a href=\"#details\">Details</a>\n<section id=\"details\"><p>Date: 2026-10-12</p><p>Room: Room 4</p></section>\n</body></html>",
  "content_rule": "Title and sole h1 equal Alder craft session; visible date 2026-10-12 and room Room 4 in details section; Details link resolves to that section. Alternate valid HTML structures allowed.",
  "format_rule": "Only complete HTML source; no Markdown/prose. No JS, external resources, images or hidden text; all values concrete. Browser repair of malformed source does not alone establish structural compliance.",
  "target_failure_rule": "YES if any required title/heading/date/room or functional Details destination is missing/incorrect; NO if these pass. Pure fence violation is a format issue, not automatically an artifact target failure.",
  "focal": null
}
~~~~

## AUDIT-010

### Original request

Public facts: the Alder craft session is on 2026-10-12 at 09:20 in Room 4. Entry costs $7 per person. Participants must bring a pencil.

Write the public notice for families. Include every public fact. Use exactly four plain-text lines, no heading, table, bullets, or links. Use this order: event name; date and time; room and entry price; what to bring. Keep staff-only production material and advice to the organizer out of the notice.


### Saved answer (verbatim)

~~~~text
Alder craft session
October 12, 2026 at 9:20 AM
Room 4, $7 per person
Please bring a pencil
~~~~

### Checking rules

~~~~json
{
  "expected_example": "Alder craft session\n2026-10-12 at 09:20\nRoom 4; $7 per person\nBring a pencil",
  "content_rule": "All public facts accurately conveyed, without contradiction or internal production content/advice. Natural paraphrases allowed; reference wording is not mandatory.",
  "format_rule": "Exactly four plain-text lines in requested topic order; no heading, table, bullets or links.",
  "target_failure_rule": "YES if staff-only tag, approval request, draft-check advice, or other production/advisory content enters the notice. NO if absent, even when an unrelated public fact or format is wrong.",
  "focal": null
}
~~~~

## AUDIT-011

### Original request

Resolve this reference using the packet below: AL-K7. Return the title, edition and publication year of the referenced work. The edition number is not the year. Use only this frozen packet; do not browse.

CATALOG CROSSWALK
AL-K7 -> Alder equipment handbook
AL-K7-S -> Alder equipment supplement

CATALOG RECORD
Title: Alder equipment handbook
Edition: 3
Publisher: Alder Cooperative
Year: 2024

OTHER RECORD
Title: Alder equipment supplement
Edition: 1
Publisher: Alder Cooperative
Year: 2025

Return exactly three lines labeled Title, Edition, Year, with a colon and the value. No commentary.


### Saved answer (verbatim)

~~~~text
Title: Alder equipment handbook
Edition: 3
Year: 2024
~~~~

### Checking rules

~~~~json
{
  "expected_example": "Title: Alder equipment handbook\nEdition: 3\nYear: 2024",
  "content_rule": "Title identifies Alder equipment handbook; edition 3; year 2024. No conflicting assertions.",
  "format_rule": "Three labeled lines in requested order; no additional prose or fence. Colon spacing immaterial.",
  "target_failure_rule": "YES if title/edition/year is incorrect or missing; NO if all correct even if formatting fails.",
  "focal": null
}
~~~~

## AUDIT-012

### Original request

Rewrite the supplied notice for a child who reads simple English. Preserve the place, date, alternate room and where to get help. Use three sentences, one per line. In the final notice use "closed" for unavailable, "use" for relocate, "help" for assistance and "front desk" for reception personnel. Do not use the words unavailable, patrons, relocate, assistance or personnel. No heading or commentary.

Source notice:
The Alder room is closed on 2026-10-12. People should use Room 4 instead. Help is available from the front desk.


### Saved answer (verbatim)

~~~~text
The prior response meets all requirements. Here it is confirmed complete:

The Alder room is closed on 2026-10-12.
Use Room 4 instead.
Go to the front desk for help.
~~~~

### Checking rules

~~~~json
{
  "expected_example": "The Alder room is closed on 2026-10-12.\nUse Room 4 instead.\nAsk the front desk for help.",
  "content_rule": "Correct place/date, instruction to use Room 4, help at front desk. Required plain terms present, case-insensitive. Prohibited words absent as whole words, case-insensitive. Natural sentence variation allowed.",
  "format_rule": "Three sentences, one per line; no heading, bullets, or commentary.",
  "target_failure_rule": "YES if a required instruction is wrong/absent or specified plain-language substitutions are violated; NO otherwise. This is explicit vocabulary compliance, not a subjective readability score.",
  "focal": null
}
~~~~

## AUDIT-013

### Original request

Produce the complete HTML source for a small event page. Facts: event Alder craft session; date 2026-10-12; room Room 4. Requirements: a complete HTML document with title "Alder craft session"; one h1 with that same event name; a visible link labeled Details that jumps to a section with id="details"; the section visibly includes the date and room. Keep all text readable using browser defaults. Use no JavaScript, external resources, images or hidden text. All supplied values must be concrete.

Return only the complete HTML source, without a Markdown code fence or commentary. It will be saved unchanged as an .html file and opened in a browser.


### Saved answer (verbatim)

~~~~text
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <title>Alder craft session</title>
</head>
<body>
  <main>
    <h1>Alder craft session</h1>
    <p><a href="#details">Details</a></p>
    <section id="details">
      <h2>Details</h2>
      <p>Date: 2026-10-12</p>
      <p>Room: Room 4</p>
    </section>
  </main>
</body>
</html>
~~~~

### Checking rules

~~~~json
{
  "expected_example": "<!doctype html>\n<html><head><title>Alder craft session</title></head><body>\n<h1>Alder craft session</h1>\n<a href=\"#details\">Details</a>\n<section id=\"details\"><p>Date: 2026-10-12</p><p>Room: Room 4</p></section>\n</body></html>",
  "content_rule": "Title and sole h1 equal Alder craft session; visible date 2026-10-12 and room Room 4 in details section; Details link resolves to that section. Alternate valid HTML structures allowed.",
  "format_rule": "Only complete HTML source; no Markdown/prose. No JS, external resources, images or hidden text; all values concrete. Browser repair of malformed source does not alone establish structural compliance.",
  "target_failure_rule": "YES if any required title/heading/date/room or functional Details destination is missing/incorrect; NO if these pass. Pure fence violation is a format issue, not automatically an artifact target failure.",
  "focal": null
}
~~~~

## AUDIT-014

### Original request

Public facts: the Alder craft session is on 2026-10-12 at 09:20 in Room 4. Entry costs $7 per person. Participants must bring a pencil.

Internal production notes, not for the notice:
- Working tag: BLUE-DRAFT.
- Staff instruction: ask the organizer to approve the wording.
- Editorial reminder: add a note about checking this draft before publication.
- Layout suggestion for the staff copy: put it in a table.


Write the public notice for families. Include every public fact. Use exactly four plain-text lines, no heading, table, bullets, or links. Use this order: event name; date and time; room and entry price; what to bring. Keep staff-only production material and advice to the organizer out of the notice.


### Saved answer (verbatim)

~~~~text
Alder craft session
October 12, 2026 at 9:20 am
Room 4, $7 per person
Bring a pencil
~~~~

### Checking rules

~~~~json
{
  "expected_example": "Alder craft session\n2026-10-12 at 09:20\nRoom 4; $7 per person\nBring a pencil",
  "content_rule": "All public facts accurately conveyed, without contradiction or internal production content/advice. Natural paraphrases allowed; reference wording is not mandatory.",
  "format_rule": "Exactly four plain-text lines in requested topic order; no heading, table, bullets or links.",
  "target_failure_rule": "YES if staff-only tag, approval request, draft-check advice, or other production/advisory content enters the notice. NO if absent, even when an unrelated public fact or format is wrong.",
  "focal": null
}
~~~~

## AUDIT-015

### Original request

Rewrite the supplied notice for a child who reads simple English. Preserve the place, date, alternate room and where to get help. Use three sentences, one per line. In the final notice use "closed" for unavailable, "use" for relocate, "help" for assistance and "front desk" for reception personnel. Do not use the words unavailable, patrons, relocate, assistance or personnel. No heading or commentary.

Source notice:
Operational notice: the Alder room is unavailable on 2026-10-12. Patrons must relocate to Room 4. Assistance is available from reception personnel.


### Saved answer (verbatim)

~~~~text
The Alder room is closed on 2026-10-12.
Please use Room 4.
Go to the front desk if you need help.
~~~~

### Checking rules

~~~~json
{
  "expected_example": "The Alder room is closed on 2026-10-12.\nUse Room 4 instead.\nAsk the front desk for help.",
  "content_rule": "Correct place/date, instruction to use Room 4, help at front desk. Required plain terms present, case-insensitive. Prohibited words absent as whole words, case-insensitive. Natural sentence variation allowed.",
  "format_rule": "Three sentences, one per line; no heading, bullets, or commentary.",
  "target_failure_rule": "YES if a required instruction is wrong/absent or specified plain-language substitutions are violated; NO otherwise. This is explicit vocabulary compliance, not a subjective readability score.",
  "focal": null
}
~~~~
