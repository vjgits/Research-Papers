from pathlib import Path
import json,hashlib,collections,re
R=Path(__file__).resolve().parent
items={x['id']:x for x in json.loads((R/'masked_packet/All_75_cases.json').read_text())}
review=json.loads((R/'RBF_study1_validation_results.json').read_text())
amend=json.loads((R/'amendment/RBF_amendment_visual_cases.json').read_text())
updates={x['id']:x for x in amend['ratings']}
assert len(items)==75 and len({x['id'] for x in review['ratings']})==75
for x in review['ratings']:
 if x['id'] in updates:
  u=updates[x['id']]
  for k,v in u['previous'].items():assert x[k]==v
  x.update({k:v for k,v in u.items() if k!='previous'})
counts={k:dict(collections.Counter(x[k] for x in review['ratings'])) for k in ['content','format','target_failure','overall']}
assert counts['overall']=={'fail':35,'pass':40}
logs=json.loads((R/'amendment/render_log.json').read_text())
assert len(logs)==9
visible=[]
for ident,log in logs.items():
 raw=items[ident]['saved_answer']
 assert hashlib.sha256(raw.encode()).hexdigest().startswith(log['sha256_saved_answer'])
 start=re.search('<!doctype html',raw,re.I).start()
 assert raw[:start].strip()==log['prose_before_doctype']
 if log['verbatim']['stray_prose_rendered']:visible.append(ident)
assert sorted(visible)==['AUDIT-009','AUDIT-029','AUDIT-038','AUDIT-074']
print(json.dumps({'amended_counts':counts,'nine_answer_hash_prefixes':'verified','reported_verbatim_commentary_cases':visible},indent=2))
print('Checks saved records only; does not independently rerender HTML or validate semantic judgments.')
