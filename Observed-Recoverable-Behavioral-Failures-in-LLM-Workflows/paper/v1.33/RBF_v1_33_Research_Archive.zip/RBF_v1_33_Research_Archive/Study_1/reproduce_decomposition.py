from pathlib import Path
import json
from collections import Counter
r=Path(__file__).resolve().parent
s=json.loads((r/'development_data/AI_screening_576.json').read_text());b={x['label']:x for x in s}
for c in 'ABCE': print(c,{k:dict(Counter(x[k] for x in s if x['condition']==c)) for k in ['content','format','overall']})
e=[x for x in s if x['condition']=='E' and x['overall']=='fail' and b[x['block']+'-A']['overall']=='pass']
assert len(e)==29 and Counter(x['content'] for x in e)=={'pass':14,'fail':3,'uncertain':12}
print('Regression content:',dict(Counter(x['content'] for x in e)))
